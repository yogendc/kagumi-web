/* ============================================================
   KONFIGURASI WEBSITE KAGUMI — satu-satunya berkas yang perlu diubah.
   GAS_URL : URL /exec yang SAMA dengan aplikasi internal (lihat js/config.js
             di folder aplikasi internal). URL ini bukan rahasia.
   WA      : (opsional) nomor WhatsApp cadangan, mis. '6281234567890'.
             Lebih mudah diisi dari aplikasi: Kelola Website → Hubungi kami.
   ============================================================ */
window.KAGUMI_WEB = {
  GAS_URL: 'TEMPEL_URL_EXEC_DI_SINI',
  WA: ''
};
